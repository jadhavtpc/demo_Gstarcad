﻿Imports System
Imports Gssoft.Gscad.ApplicationServices

Imports Gssoft.Gscad.Colors
Imports Gssoft.Gscad.DatabaseServices
Imports Gssoft.Gscad.EditorInput
Imports Gssoft.Gscad.Geometry
Imports Gssoft.Gscad.PlottingServices
Imports Gssoft.Gscad.Runtime
Imports Gssoft.Gscad.Internal
Imports Gssoft.Gscad.Runtime
Imports GrxCAD.Runtime
Imports GrxCAD.DatabaseServices

<Assembly: CommandClass(GetType(DemoVB_GCAD.DemoGCad))>

Namespace DemoVB_GCAD
	Public Class DemoGCad
		<CommandMethod("gccad", CommandFlags.Modal)>
		Public Sub TurnLayerAction()
			Dim Userform1 As New UserForm()
			Userform1.Show()
		End Sub

		<CommandMethod("vbhello", CommandFlags.Modal)>
		Public Sub RunMRLCommand() ' This method can have any name
			Dim doc As GrxCAD.ApplicationServices.Document
			Dim ent As Entity


			doc = GrxCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
			doc.Editor.WriteMessage("hello vb.net")
		End Sub
	End Class
End Namespace