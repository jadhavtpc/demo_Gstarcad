﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserForm
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Dim ListViewItem6 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("")
		Dim ListViewItem7 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("")
		Dim ListViewItem8 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("")
		Dim ListViewItem9 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("")
		Dim ListViewItem10 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("")
		Me.Button1 = New System.Windows.Forms.Button()
		Me.lstLayerList = New System.Windows.Forms.ListView()
		Me.LstActionList = New System.Windows.Forms.ListView()
		Me.LayerName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
		Me.Action = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
		Me.Label1 = New System.Windows.Forms.Label()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.cmbActionList = New System.Windows.Forms.ComboBox()
		Me.Button2 = New System.Windows.Forms.Button()
		Me.SuspendLayout()
		'
		'Button1
		'
		Me.Button1.Location = New System.Drawing.Point(12, 325)
		Me.Button1.Name = "Button1"
		Me.Button1.Size = New System.Drawing.Size(213, 25)
		Me.Button1.TabIndex = 0
		Me.Button1.Text = "Show Layers List From Drawing"
		Me.Button1.UseVisualStyleBackColor = True
		'
		'lstLayerList
		'
		Me.lstLayerList.FullRowSelect = True
		Me.lstLayerList.GridLines = True
		Me.lstLayerList.HideSelection = False
		Me.lstLayerList.Location = New System.Drawing.Point(12, 139)
		Me.lstLayerList.Name = "lstLayerList"
		Me.lstLayerList.Size = New System.Drawing.Size(316, 166)
		Me.lstLayerList.TabIndex = 2
		Me.lstLayerList.UseCompatibleStateImageBehavior = False
		'
		'LstActionList
		'
		Me.LstActionList.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.LayerName, Me.Action})
		Me.LstActionList.HideSelection = False
		Me.LstActionList.Items.AddRange(New System.Windows.Forms.ListViewItem() {ListViewItem6, ListViewItem7, ListViewItem8, ListViewItem9, ListViewItem10})
		Me.LstActionList.Location = New System.Drawing.Point(389, 139)
		Me.LstActionList.Name = "LstActionList"
		Me.LstActionList.Size = New System.Drawing.Size(487, 166)
		Me.LstActionList.TabIndex = 3
		Me.LstActionList.UseCompatibleStateImageBehavior = False
		Me.LstActionList.View = System.Windows.Forms.View.SmallIcon
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
		Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.Location = New System.Drawing.Point(12, 107)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(94, 20)
		Me.Label1.TabIndex = 4
		Me.Label1.Text = "Layer List"
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
		Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.Location = New System.Drawing.Point(385, 107)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(94, 20)
		Me.Label2.TabIndex = 5
		Me.Label2.Text = "Layer List"
		'
		'Label3
		'
		Me.Label3.AutoSize = True
		Me.Label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
		Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label3.Location = New System.Drawing.Point(334, 215)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(38, 25)
		Me.Label3.TabIndex = 6
		Me.Label3.Text = "=>"
		'
		'cmbActionList
		'
		Me.cmbActionList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cmbActionList.FormattingEnabled = True
		Me.cmbActionList.Items.AddRange(New Object() {"ON", "OFF", "FREEZE", "THAW"})
		Me.cmbActionList.Location = New System.Drawing.Point(494, 107)
		Me.cmbActionList.Name = "cmbActionList"
		Me.cmbActionList.Size = New System.Drawing.Size(154, 24)
		Me.cmbActionList.TabIndex = 7
		'
		'Button2
		'
		Me.Button2.Location = New System.Drawing.Point(654, 108)
		Me.Button2.Name = "Button2"
		Me.Button2.Size = New System.Drawing.Size(88, 25)
		Me.Button2.TabIndex = 8
		Me.Button2.Text = "Do Action"
		Me.Button2.UseVisualStyleBackColor = True
		'
		'UserForm
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(1050, 450)
		Me.Controls.Add(Me.Button2)
		Me.Controls.Add(Me.cmbActionList)
		Me.Controls.Add(Me.Label3)
		Me.Controls.Add(Me.Label2)
		Me.Controls.Add(Me.Label1)
		Me.Controls.Add(Me.LstActionList)
		Me.Controls.Add(Me.lstLayerList)
		Me.Controls.Add(Me.Button1)
		Me.Name = "UserForm"
		Me.Text = "User Form"
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

	Friend WithEvents Button1 As Windows.Forms.Button
	Friend WithEvents lstLayerList As Windows.Forms.ListView
	Friend WithEvents LstActionList As Windows.Forms.ListView
	Friend WithEvents Label1 As Windows.Forms.Label
	Friend WithEvents Label2 As Windows.Forms.Label
	Friend WithEvents Label3 As Windows.Forms.Label
	Friend WithEvents cmbActionList As Windows.Forms.ComboBox
	Friend WithEvents LayerName As Windows.Forms.ColumnHeader
	Friend WithEvents Action As Windows.Forms.ColumnHeader
	Friend WithEvents Button2 As Windows.Forms.Button
End Class
