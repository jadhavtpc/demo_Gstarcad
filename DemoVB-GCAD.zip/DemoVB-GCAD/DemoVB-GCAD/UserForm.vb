﻿Imports System
'Imports Gssoft.Gscad
'Imports Gssoft.Gscad.Runtime
'Imports Gssoft.Gscad.DatabaseServices
'Imports Gssoft.Gscad.Geometry
'Imports Gssoft.Gscad.ApplicationServices
'Imports Gssoft.Gscad.EditorInput
Imports System.Windows.Forms
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports _accolor = Gssoft.Gscad.Colors



Imports Gssoft.Gscad.ApplicationServices
Imports _AcCm = Gssoft.Gscad.Colors
Imports _AcDb = Gssoft.Gscad.DatabaseServices
Imports _AcEd = Gssoft.Gscad.EditorInput
Imports _AcGe = Gssoft.Gscad.Geometry
Imports _AcPl = Gssoft.Gscad.PlottingServices
Imports _AcBrx = Gssoft.Gscad.Runtime
Imports _AcInt = Gssoft.Gscad.Internal
'Imports Gssoft.Gscad.Colors
'Imports Gssoft.Gscad.DatabaseServices.Filters
'Imports Gssoft.Gscad.DatabaseServices
Imports DemoVB_GCAD.Class1
Imports GrxCAD.DatabaseServices
Imports GrxCAD.Runtime
Imports GrxCAD.ApplicationServices
Imports GrxCAD.Colors
Imports GrxCAD.Geometry

'Imports Gssoft.Gscad.DatabaseServices

Public Class UserForm
	Private objclass1 As DemoVB_GCAD.Class1
	'Public Property NewProperty() As Class1
	'	Get
	'		Return objclass1
	'	End Get
	'	Set(ByVal value As Class1)
	'		objclass1 = value
	'	End Set
	'End Property
	Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
		Dim regs1 As New ResultBuffer()
		Dim list As New List(Of String)

		For index = 0 To LstActionList.SelectedItems.Count - 1
			'regs1 = New ResultBuffer(
			'   New TypedValue(CInt(DxfCode.Text), LstActionList.SelectedItems(index).SubItems(0).ToString()),
			'	New TypedValue(CInt(DxfCode.Text), LstActionList.SelectedItems(index).SubItems(1).ToString())
			list = New List(Of String)
			list.Add(LstActionList.SelectedItems(index).SubItems(0).Text.ToString())
			list.Add(cmbActionList.Text.ToString())
			objclass1.TurnLayerAction(list)
		Next

		'System.Windows.Forms.MessageBox.Show(cmbActionList.SelectedText.ToString() + " completed successfully ")

		'objclass1.ShoUserMessage("button clicked ")
		'TurnLayerAction(regs1)
		System.Windows.Forms.MessageBox.Show(cmbActionList.SelectedText.ToString() + " completed successfully ")
	End Sub

	Private Sub UserForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
		objclass1 = New DemoVB_GCAD.Class1()
		lstLayerList.Clear()
		lstLayerList.Columns.Add("LayerName", 100)
		lstLayerList.View = View.Details
		lstLayerList.GridLines = True
		lstLayerList.FullRowSelect = True

		LstActionList.Clear()
		LstActionList.Columns.Add("LayerName", 100)
		LstActionList.Columns.Add("Last Action", 100)
		LstActionList.View = View.Details
		LstActionList.GridLines = True
		LstActionList.FullRowSelect = True
		cmbActionList.SelectedIndex = 0

	End Sub

	Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

		Dim lstlayer As List(Of String)
		lstlayer = GetAllLayer()

		Dim itm As ListViewItem

		For Each layerbnm As String In lstlayer
			itm = New ListViewItem(layerbnm)
			lstLayerList.Items.Add(itm)
		Next

		System.Windows.Forms.MessageBox.Show("list collection completed successfully ")
	End Sub

	Function GetAllLayer() As List(Of String)
		Dim LasyerLst As New List(Of String)()

		Dim acDoc As Document = GrxCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
		Dim acCurDb As Database = acDoc.Database
		'' Start a transaction
		Using acTrans As Transaction = acCurDb.TransactionManager.StartTransaction()

			'' Open the Layer table for read
			Dim acLyrTbl As LayerTable
			acLyrTbl = acTrans.GetObject(acCurDb.LayerTableId, OpenMode.ForRead)

			For Each acObjId As ObjectId In acLyrTbl
				Dim acLyrTblRec As LayerTableRecord
				acLyrTblRec = acTrans.GetObject(acObjId, OpenMode.ForRead)
				LasyerLst.Add(acLyrTblRec.Name)
			Next

			acTrans.Dispose()
		End Using


		Return LasyerLst
	End Function

	Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
		Dim ProductName As String = ""

		Dim arr As String() = New String(2) {}
		Dim itm As ListViewItem
		For index = 0 To lstLayerList.SelectedItems.Count - 1
			ProductName = lstLayerList.SelectedItems(index).SubItems(0).Text
			'add items to ListView
			arr(0) = ProductName
			arr(1) = ""
			itm = New ListViewItem(arr)
			LstActionList.Items.Add(itm)
		Next


	End Sub

	<LispFunction("CreateAndAssignALayer")>
	Public Function CreateAndAssignALayer(ByVal rbArgs As ResultBuffer) As ResultBuffer
		'' Get the current document and database
		Dim retn As New ResultBuffer
		Dim sLayerName As String = rbArgs.AsArray()(0).Value.ToString()
		Dim acDoc As Document = GrxCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
		Dim acCurDb As Database = acDoc.Database

		'' Start a transaction
		Using acTrans As Transaction = acCurDb.TransactionManager.StartTransaction()

			'' Open the Layer table for read
			Dim acLyrTbl As LayerTable
			acLyrTbl = acTrans.GetObject(acCurDb.LayerTableId, OpenMode.ForRead)

			'Dim sLayerName As String = "Center"

			If acLyrTbl.Has(sLayerName) = False Then
				Using acLyrTblRec As LayerTableRecord = New LayerTableRecord()

					'' Assign the layer the ACI color 3 and a name
					acLyrTblRec.Color = Color.FromColorIndex(ColorMethod.ByAci, 3)
					acLyrTblRec.Name = sLayerName

					'' Upgrade the Layer table for write
					acTrans.GetObject(acCurDb.LayerTableId, OpenMode.ForWrite)

					'' Append the new layer to the Layer table and the transaction
					acLyrTbl.Add(acLyrTblRec)
					acTrans.AddNewlyCreatedDBObject(acLyrTblRec, True)
				End Using
			End If

			'' Open the Block table for read
			Dim acBlkTbl As BlockTable
			acBlkTbl = acTrans.GetObject(acCurDb.BlockTableId, OpenMode.ForRead)

			'' Open the Block table record Model space for write
			Dim acBlkTblRec As BlockTableRecord
			acBlkTblRec = acTrans.GetObject(acBlkTbl(BlockTableRecord.ModelSpace),
										OpenMode.ForWrite)

			'' Create a circle object
			Using acCirc As Circle = New Circle()
				acCirc.Center = New Point3d(2, 2, 0)
				acCirc.Radius = 1
				acCirc.Layer = sLayerName

				acBlkTblRec.AppendEntity(acCirc)
				acTrans.AddNewlyCreatedDBObject(acCirc, True)
			End Using

			'' Save the changes and dispose of the transaction
			acTrans.Commit()
		End Using
		Return retn
	End Function

End Class
