﻿'Imports System
'Imports Gssoft.Gscad
'Imports Gssoft.Gscad.Runtime
'Imports Gssoft.Gscad.DatabaseServices
'Imports Gssoft.Gscad.Geometry
'Imports Gssoft.Gscad.ApplicationServices
'Imports Gssoft.Gscad.EditorInput


Imports _AcAp = Gssoft.Gscad.ApplicationServices

Imports _AcCm = Gssoft.Gscad.Colors
Imports _AcDb = Gssoft.Gscad.DatabaseServices
Imports _AcEd = Gssoft.Gscad.EditorInput
Imports _AcGe = Gssoft.Gscad.Geometry
Imports _AcPl = Gssoft.Gscad.PlottingServices
Imports _AcBrx = Gssoft.Gscad.Runtime
Imports _AcInt = Gssoft.Gscad.Internal
Imports GrxCAD.DatabaseServices
Imports GrxCAD.ApplicationServices
Imports GrxCAD.Runtime
Imports GrxCAD.Geometry


'Using System.Data.OleDb;
'Using System.Data;
'Using tpc_DAL;
'Using System.Xml.Linq;
'//using ZwSoft.ZwCAD.DatabaseServices;
'Using System.Xml.XPath;
'Using System.IO;

'/*using MySqlConnector;*/
'Using _Acplot = Gssoft.Gscad.PlottingServices;
'Using System.Net.Http;
'Using Newtonsoft.Json.Linq;
'Using Newtonsoft.Json;
'Using System.Net.Http.Headers;
'Using Gssoft.Gscad.ApplicationServices;
'Using Gssoft.Gscad.DatabaseServices;
'Using Gssoft.Gscad.Geometry;
'Using Gssoft.Gscad.Runtime;
'//using ZwSoft.ZwCAD.ApplicationServices;



'//using tpc_DAL;
'//using System.Data.OleDb;

'//[assembly _AcBrx.ExtensionApplication(null)]
'[assembly: _AcBrx.CommandClass(TypeOf (PEB_GstartCAD.GSTAR_Class))]
'//[assembly:_AcBrx.ExtensionApplication(TypeOf (tpcACAD.HelloWorldCommands))]
Namespace DemoVB_GCAD
	Public Class Class1
		'_AcDb.ResultBuffer resBufOut = New _AcDb.ResultBuffer();
		'String plotname = rbArgs.AsArray()[0].Value.ToString();
		'String plotPaper = rbArgs.AsArray()[1].Value.ToString();

		'<LispFunction("turnLayerOff")>
		Public Sub TurnLayerAction(ByVal rbArgs As List(Of String))
			'' Get the current document and database
			Dim sLayerName As String = rbArgs(0).ToString()
			Dim ActionName As String = rbArgs(1).ToString()

			Dim acDoc As Document = Application.DocumentManager.MdiActiveDocument
			Dim acCurDb As Database = acDoc.Database
			Dim actionVal As Boolean = True

			If (ActionName.ToString() = "OFF") Then actionVal = False
			If (ActionName.ToString() = "FREEZE") Then actionVal = True Else actionVal = False
			'' Start a transaction
			Using acTrans As Transaction = acCurDb.TransactionManager.StartTransaction()

				'' Open the Layer table for read
				Dim acLyrTbl As LayerTable
				acLyrTbl = acTrans.GetObject(acCurDb.LayerTableId, OpenMode.ForRead)

				'Dim sLayerName As String = "ABC"

				If acLyrTbl.Has(sLayerName) = False Then
					Using acLyrTblRec As LayerTableRecord = New LayerTableRecord()

						'' Assign the layer a name
						acLyrTblRec.Name = sLayerName

						Select Case ActionName.ToString()
							Case "OFF"
								Debug.WriteLine("OFF")
								'' Turn the layer off
								acLyrTblRec.IsOff = True
						' The following is the only Case clause that evaluates to True.
							Case "ON"
								Debug.WriteLine("ON")
								acLyrTblRec.IsOff = False
							Case "FREEZE"
								Debug.WriteLine("FREEZE")
								'' Freeze the layer
								acLyrTblRec.IsFrozen = True
							Case "THAW"
								Debug.WriteLine("THAW")
								acLyrTblRec.IsFrozen = False
						End Select


						'' Upgrade the Layer table for write
						acTrans.GetObject(acCurDb.LayerTableId, OpenMode.ForWrite)

						'' Append the new layer to the Layer table and the transaction
						acLyrTbl.Add(acLyrTblRec)
						acTrans.AddNewlyCreatedDBObject(acLyrTblRec, True)
					End Using
				Else
					Dim acLyrTblRec As LayerTableRecord = acTrans.GetObject(acLyrTbl(sLayerName), OpenMode.ForWrite)

					Select Case ActionName.ToString()
						Case "OFF"
							Debug.WriteLine("OFF")
							'' Turn the layer off
							acLyrTblRec.IsOff = True
						' The following is the only Case clause that evaluates to True.
						Case "ON"
							Debug.WriteLine("ON")
							acLyrTblRec.IsOff = False
						Case "FREEZE"
							Debug.WriteLine("FREEZE")
							'' Freeze the layer
							acLyrTblRec.IsFrozen = True
						Case "THAW"
							Debug.WriteLine("THAW")
							acLyrTblRec.IsFrozen = False
					End Select

				End If

				'' Open the Block table for read
				Dim acBlkTbl As BlockTable
				acBlkTbl = acTrans.GetObject(acCurDb.BlockTableId, OpenMode.ForRead)

				'' Open the Block table record Model space for write
				Dim acBlkTblRec As BlockTableRecord
				acBlkTblRec = acTrans.GetObject(acBlkTbl(BlockTableRecord.ModelSpace), OpenMode.ForWrite)

				'' Create a circle object
				Using acCirc As Circle = New Circle()
					acCirc.Center = New Point3d(2, 2, 0)
					acCirc.Radius = 1
					acCirc.Layer = sLayerName

					acBlkTblRec.AppendEntity(acCirc)
					acTrans.AddNewlyCreatedDBObject(acCirc, True)
				End Using

				'' Save the changes and dispose of the transaction
				acTrans.Commit()
			End Using
		End Sub

		'Public Function UpdateLayerStatus(ByVal string) As Boolean

		'    Return 0
		'End Function

		Public Shared Sub ShoUserMessage(ByVal msg As String)
			System.Windows.Forms.MessageBox.Show(msg)
		End Sub
	End Class
End Namespace